import { useState } from 'react';


const CustomToken = () => {
    const [select, setSelect] = useState('Hold Tokens');
    return (
    <>
    </>
    )
}

export default CustomToken
